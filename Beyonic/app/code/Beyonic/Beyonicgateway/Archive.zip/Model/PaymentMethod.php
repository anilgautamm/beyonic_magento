<?php

namespace Beyonic\Beyonicgateway\Model;

class PaymentMethod extends \Magento\Payment\Model\Method\AbstractMethod {

    protected $_code = 'beyonicgateway';
}
